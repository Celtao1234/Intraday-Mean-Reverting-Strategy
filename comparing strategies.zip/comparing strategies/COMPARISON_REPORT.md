# Strategy Comparison Report

## Winner

**Strategy 3** (Results_3.csv)

- Net PnL: ₹484,323.78
- Win Rate: 70.6%
- Contracts: 1,554

## All Strategies

| Rank | Strategy | Net PnL | Contracts | Win Rate | Profit Factor |
|------|----------|---------|-----------|----------|---------------|
| 1 | Strategy 3 | ₹484,324 | 1,554 | 70.6% | 2.45 |
| 2 | Strategy 2 | ₹-1,219 | 338 | 83.3% | 0.98 |
| 3 | Strategy 1 | ₹-287,929 | 1,422 | 30.0% | 0.12 |
